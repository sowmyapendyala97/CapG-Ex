package lab5;

import java.util.Scanner;
import java.util.*;

public class Five {

	public static void main(String[] args) {

		System.out.println("enter the number");
		Scanner s=new Scanner(System.in);
		int sum=0;
		int n1=s.nextInt();
		
		while(n1!=0)
		{
	int n=n1%10;
			sum=sum+n*n*n;
			n1=n1/10;
			
			
		}
		
		System.out.println(sum);
		
		// TODO Auto-generated method stub

	}

}
