

	public class CD extends MediaItem 
	{
		public CD(int id, String title, int copies) {
			super(id, title, copies);
			// TODO Auto-generated constructor stub
		}

		private String artist;
			private String genre;
		}




